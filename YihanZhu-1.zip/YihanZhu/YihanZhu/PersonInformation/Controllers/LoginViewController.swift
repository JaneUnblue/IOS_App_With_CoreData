//
//  LoginViewController.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 11/4/24.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var textFieldName: UITextField!
    @IBOutlet weak var textFieldPWD: UITextField!
    
    @IBOutlet weak var textFieldResult: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
    }
    
    func login() -> Bool {
        
        guard let name = textFieldName.text, !name.isEmpty else {
            // not allow empty
            showAlert(title: "Tips", message: "Username can not be empty!")
            return false
        }
    
        guard let password = textFieldPWD.text, !password.isEmpty else {
            // not allow empty
            showAlert(title: "Tips", message: "Password can not be empty!")
            return false
        }
        
        guard let user = UsersDataServices.shared.fetchByName(name) else {
            // user not found
            showAlert(title: "Tips", message: "User does not exist.")
            return false
        }
        
        if let u_password = user.password, u_password == password {
            textFieldResult.text = "Login successfully！"
            return true
        } else {
            textFieldResult.text = "Password not correct."
        }
        
        
        return false
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
       
    }
    
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "segue0" {
            let result = login()
            return result
        }
        return false
    }
    
}
