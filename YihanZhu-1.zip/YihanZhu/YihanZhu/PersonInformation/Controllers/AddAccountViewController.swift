//
//  AddAccountViewController.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 11/4/24.
//

import UIKit

class AddAccountViewController: UIViewController {

    @IBOutlet weak var textFieldName: UITextField!
    
    @IBOutlet weak var textFieldPassword: UITextField!
    
    var isUpdate: Bool = false
    var user: Users?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if isUpdate {
            textFieldName.text = user?.name
            textFieldPassword.text = user?.password
        }
    }
    

    @IBAction func btnSaveAction(_ sender: Any) {
        guard let name = textFieldName.text?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else {
            showAlert(title: "Tips", message: "Username can not be empty!")
            return
        }
        guard let password = textFieldPassword.text?.trimmingCharacters(in: .whitespacesAndNewlines), !password.isEmpty else {
            showAlert(title: "Tips", message: "Password can not be empty!")
            return
        }
        
        if isUpdate {
            if let user = user {
                user.name = name
                user.password = password
                UsersDataServices.shared.update(entity: user)
                showAlert(title: "Tips", message: "Successfully modified.")
            }
            
           
        } else {
            let user = Users(context: UsersDataServices.shared.context)
            user.name = name
            user.password = password
            UsersDataServices.shared.create(entity: user)
            showAlert(title: "Tips", message: "Account successfully created.")
        }
    
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
