//
//  WebViewController.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 19/02/2024.
//

import UIKit
import WebKit//youshould do

class WebViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    
    var webURL : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let urlWeb = URL(string: webURL) ?? URL(string: "https://www.breakingnews.ie/")
        let webURLRequest = URLRequest(url: urlWeb!)
        webView.load(webURLRequest)

        // Do any additional setup after loading the view.
    }
    
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
  

}
