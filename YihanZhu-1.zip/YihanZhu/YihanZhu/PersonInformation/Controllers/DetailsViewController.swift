//
//  DetailsViewController.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 09/02/2024.
//

import UIKit

class DetailsViewController: UIViewController {
    //outlets
    
    @IBOutlet weak var textView: UITextView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var urlLabel: UILabel!
    
    //vars and methods
    var personData:Players!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        nameLabel.text = personData.name
        textView.text = personData.details
        textView.contentInset=UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
    }
    
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "webSegue"{
            //get new view controller
            let destination = segue.destination as! WebViewController
            
            //pass the required data to the new contreoller
            destination.webURL = personData.url
        }
    }
    
    
}
