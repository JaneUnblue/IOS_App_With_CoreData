//
//  UIViewController.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 11/4/24.
//

import UIKit

extension UIViewController {
    
    func showAlert(title: String?, message: String?) {
        let alertVC = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "Done", style: .default, handler: { _ in
            
        }))
        present(alertVC, animated: true)
    }
}
