//
//  PersonViewController.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 09/02/2024.
//

import UIKit

class PersonViewController: UIViewController {
    
    //outlets and actions
    @IBOutlet weak var personImageView: UIImageView!
    
    @IBOutlet weak var personNameLabel: UILabel!

    @IBOutlet weak var personAge: UILabel!
    
    @IBOutlet weak var personHeight: UILabel!

    @IBOutlet weak var btnFavorite: UIButton!
    
    //model data
//    var personData: Person!
    
    var dataSource: [Players] = []

    var count: Int = 0
    var index: Int = 0
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        personAge.layer.cornerRadius = personAge.frame.size.width / 2
        personHeight.layer.cornerRadius = personAge.frame.size.width / 2

        personAge.clipsToBounds = true
        personHeight.clipsToBounds = true
      
        
        // Do any additional setup after loading the view.
      
        loadData()
        
        
        
        //fill the label and image view with data
    }
    
    func loadData() {
        
        personNameLabel.text = dataSource[index].name // personData.name
        personAge.text = dataSource[index].address
        personHeight.text = dataSource[index].phone//
        personImageView.image = UIImage(named: dataSource[index].image!)
        btnFavorite.isSelected = dataSource[index].isFavorite
    }
    
    
    @IBAction func btnPreviousAction(_ sender: Any) {
        //-1
        if index > 0  {
            index = index - 1
            loadData()
        }
    }
    
    @IBAction func btnNextAction(_ sender: Any) {
        //+1
        if index < count - 1  {
            index = index + 1
            loadData()
        }
    }
    
    
    @IBAction func btnFavouriteAction(_ sender: Any) {
        
        btnFavorite.isSelected = !btnFavorite.isSelected
        
        // if exits, cancel
        let player = dataSource[index]
        
        player.isFavorite = !player.isFavorite
        
        PlayersDataServices.shared.update(entity: player)
        
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue1"{
        
            // Get the new view controller using segue.destination.
//            
         let destination=segue.destination as! DetailsViewController
            
            
//            // Find and Pass the selected object to the new view controller.
            destination.personData = dataSource[index] //self.personData
        }
        
    }
        
}
