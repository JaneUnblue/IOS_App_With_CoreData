//
//  XMLUserModelParser.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 11/4/24.
//

import UIKit

class XMLUserModelParser: NSObject, XMLParserDelegate {
    var users: [UserModel] = []
    var currentUser: UserModel?
    var currentElementValue: String?
    var xmlParser: XMLParser?
    
    init(xmlData: Data) {
        super.init()
        xmlParser = XMLParser(data: xmlData)
        xmlParser?.delegate = self
    }
    
    func parse() {
        users = []
        xmlParser?.parse()
    }
    
    // MARK: - XMLParserDelegate methods
    
    func parserDidStartDocument(_ parser: XMLParser) {
        // Initialize data when parsing starts
        users = []
        currentElementValue = ""
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        // Create a new UserModel object when user element starts
        if elementName == "user" {
            currentUser = UserModel()
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        // Save element value to currentElementValue when found
        currentElementValue? += string
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        // Assign value to UserModel object's corresponding property when element ends
        if elementName == "name" {
            currentUser?.name = currentElementValue?.trimmingCharacters(in: .whitespacesAndNewlines)
        } else if elementName == "password" {
            currentUser?.password = currentElementValue?.trimmingCharacters(in: .whitespacesAndNewlines)
        } else if elementName == "user" {
            // Add the current UserModel object to users array when user element ends
            if let user = currentUser {
                users.append(user)
                currentUser = nil
            }
        }
        // Clear currentElementValue for next element
        currentElementValue = ""
    }
    
    func parserDidEndDocument(_ parser: XMLParser) {
        // Perform any action needed when parsing ends, e.g., print parsing result
        for user in users {
            print("User: \(user)")
        }
    }
}
