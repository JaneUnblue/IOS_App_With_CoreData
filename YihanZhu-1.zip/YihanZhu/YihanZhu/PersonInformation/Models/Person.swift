//
//  Person.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 09/02/2024.
//

import Foundation

class Person{
    
    
    //class properties
    var name, address, phone, image, url, details:String
    
    
    
    //class init-s
    init(name: String, address: String, phone: String, image: String, url: String, details: String) {
        self.name = name
        self.address = address
        self.phone = phone
        self.image = image
        self.url = url
        self.details = details
    }
    init() {
        self.name = "John Doe"
        self.address = "no address"
        self.phone = "no phone"
        self.image = "doe.jpg"
        self.url = "na"
        self.details = "na"
    }
    
    
    
    //class methods
    
    
}
