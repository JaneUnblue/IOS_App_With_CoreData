//
//  XMLPeopleParser.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 23/02/2024.
//

import Foundation

class XMLPeopleParser:NSObject,XMLParserDelegate
{
    var xmlName:String
    
    init(xmlName: String) {
        self.xmlName = xmlName
        
        
    }
    //parsed variable definition
    var name,address,phone,image,url,details:String!
    let tags = ["name","address","phone","image","url","details"]
    
    
    //variables for spying
    var elementId = -1
    var passData = false
    
    
    var personData: Person!
    var peopleData = [Person]()
    
    //parser objext
    var parser:XMLParser!
    
    //MARK: parsing methods
    //didStart
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        if tags.contains(elementName){
            //spying
            passData = true
            //chat what tags to spy
            switch elementName{
                case "name" :elementId = 0
                case "address" :elementId = 1
                case "phone" :elementId = 2
                case "image" :elementId = 3
                case "url" :elementId = 4
                case "details" :elementId = 5
                default: break
            }
        }
    }
    //didEndElement
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if tags.contains(elementName){
            passData = false
            elementId = -1
        }
        if elementName == "person" {
            personData = Person(name: name, address: address, phone: phone, image: image, url: url, details: details)
            peopleData.append(personData)
        }
    }
    //found characters
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        if passData{
            switch elementId{
                case 0 : name = string
                case 1 : address = string
                case 2: phone = string
                case 3: image = string
                case 4: url = string
                case 5: details = string
                default: break
                
            }
        }
    }
    func parsing(){
        let bundle = Bundle.main.bundleURL
        let bundleURL = NSURL(fileURLWithPath: self.xmlName, relativeTo: bundle)
        
        //make the parser
        parser = XMLParser(contentsOf: bundleURL as URL)
        parser.delegate = self
        parser.parse()
    }
    
}
