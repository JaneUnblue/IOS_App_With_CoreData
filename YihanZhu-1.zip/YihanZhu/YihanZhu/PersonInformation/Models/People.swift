//
//  People.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 12/02/2024.
//

import Foundation
class People{
    var peopleData:[Person]
    
    init(){
        peopleData=[
            Person(name: "Sabin", address: "WGB", phone: "1234567", image: "images.jpeg", url:"https://www.breakingnews.ie/", details: "Sabin"),
            Person(name: "Grace", address: "China", phone: "0000000", image: "images.jpeg", url:"https://www.breakingnews.ie/", details: "Sabin"),
            Person(name: "France", address: "Cork", phone: "34857938", image: "images.jpeg", url: "https://www.breakingnews.ie/", details: "Sabin"),
            Person(name: "Harry", address: "UK", phone: "678237", image: "images.jpeg", url: "https://www.breakingnews.ie/", details: "Sabin")]
    }
    
    
    init(fromXMLfile: String) {
        let xmlPeopleParser =
            XMLPeopleParser(xmlName: fromXMLfile)
        xmlPeopleParser.parsing()
        self.peopleData = xmlPeopleParser.peopleData
    }
    
    func getPerson(index:Int)->Person{
        return peopleData[index]
    }
        
    func getCount()-> Int {
        return peopleData.count
        
    }
    
}
