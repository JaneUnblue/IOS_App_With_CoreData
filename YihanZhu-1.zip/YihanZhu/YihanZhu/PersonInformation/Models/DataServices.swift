//
//  DataServices.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 11/4/24.
//

import UIKit
import CoreData

protocol CoreDataServices {
    associatedtype Entity: NSManagedObject
    
    func create(entity: Entity)
    func fetchAll() -> [Entity]
    func update(entity: Entity)
    func delete(entity: Entity)
    func fetchByName(_ name: String) -> Entity?
}

class PlayersDataServices: CoreDataServices {
    
    typealias Entity = Players
    
    static let shared = PlayersDataServices()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func create(entity: Players) {
        do {
            try context.save()
        } catch {
            print("Error saving context: \(error)")
        }
    }
    
    func fetchAll() -> [Players] {
        var players = [Players]()
        let request: NSFetchRequest<Players> = Players.fetchRequest()
        do {
            players = try context.fetch(request)
        } catch {
            print("Error fetching : \(error)")
        }
        return players
    }
    
    func update(entity: Players) {
        do {
            try context.save()
        } catch {
            print("Error saving context: \(error)")
        }
    }
    
    func delete(entity: Players) {
        context.delete(entity)
        do {
            try context.save()
        } catch {
            print("Error saving context: \(error)")
        }
    }
    
    func fetchByName(_ name: String) -> Players? {
        var players = [Players]()
        let request: NSFetchRequest<Players> = Players.fetchRequest()
        request.predicate = NSPredicate(format: "name == %@", name as CVarArg)
        do {
            players = try context.fetch(request)
        } catch {
            print("Error fetching : \(error)")
        }
        return players.first
    }
    
    func fetchFavoriteAll() -> [Players] {
        var players = [Players]()
        let request: NSFetchRequest<Players> = Players.fetchRequest()
        request.predicate = NSPredicate(format: "isFavorite == true")
        do {
            players = try context.fetch(request)
        } catch {
            print("Error fetching : \(error)")
        }
        return players
    }
    
}


class UsersDataServices: CoreDataServices {
    
    typealias Entity = Users
    static let shared = UsersDataServices()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func create(entity: Users) {
        do {
            try context.save()
        } catch {
            print("Error saving context: \(error)")
        }
    }
    
    func fetchAll() -> [Users] {
        var users = [Users]()
        let request: NSFetchRequest<Users> = Users.fetchRequest()
        do {
            users = try context.fetch(request)
        } catch {
            print("Error fetching FavoriteMaps: \(error)")
        }
        return users
    }
    
    func update(entity: Users) {
        do {
            try context.save()
        } catch {
            print("Error saving context: \(error)")
        }
    }
    
    func delete(entity: Users) {
        context.delete(entity)
        do {
            try context.save()
        } catch {
            print("Error saving context: \(error)")
        }
    }
    
    
    func fetchByName(_ name: String) -> Users? {
        var users = [Users]()
        let request: NSFetchRequest<Users> = Users.fetchRequest()
        request.predicate = NSPredicate(format: "name == %@", name as CVarArg)
        do {
            users = try context.fetch(request)
        } catch {
            print("Error fetching : \(error)")
        }
        return users.first
    }
}


