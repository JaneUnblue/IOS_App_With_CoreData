//
//  UserModel.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 19/4/24.
//

import UIKit

class UserModel {
    var name: String?
    var password: String?
}
