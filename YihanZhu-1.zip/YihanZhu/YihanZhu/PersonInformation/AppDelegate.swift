//
//  AppDelegate.swift
//  PersonInformation
//
//  Created by ZHU YIHAN on 09/02/2024.
//

import UIKit
import CoreData


@main
class AppDelegate: UIResponder, UIApplicationDelegate {



    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        let isFirstLaunch = UserDefaults.standard.bool(forKey: "isFirstLaunch")
        if !isFirstLaunch {
            // If first launch, import data.   xml  =>  Coredata
            
            let peopleData : People = People(fromXMLfile: "people.xml")
            for person in peopleData.peopleData {
                
                let player = Players(context: PlayersDataServices.shared.context)
                player.name = person.name
                player.address = person.address
                player.phone = person.phone
                player.image = person.image
                player.url = person.url
                player.details = person.details
                player.isFavorite = false
                
                PlayersDataServices.shared.create(entity: player)
            }
            
            let bundle = Bundle.main.bundleURL
            let bundleURL = NSURL(fileURLWithPath: "user.xml", relativeTo: bundle)
            
            if let xmlData = try? Data(contentsOf: bundleURL as URL) {
                let xmlParser = XMLUserModelParser(xmlData: xmlData)
                xmlParser.parse()
                
                let users = xmlParser.users
                
                for user in users {
                    let _user = Users(context: UsersDataServices.shared.context)
                    _user.name = user.name
                    _user.password = user.password
                    UsersDataServices.shared.create(entity: _user)
                }
                
            }
            
            UserDefaults.standard.setValue(true, forKey: "isFirstLaunch")
        }
        
        
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }

    // MARK: - Core Data stack

    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "PersonModel")
        container.loadPersistentStores { (storeDescription, error) in
            
        }
        return container
    }()
    
    func saveContent() {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

}

